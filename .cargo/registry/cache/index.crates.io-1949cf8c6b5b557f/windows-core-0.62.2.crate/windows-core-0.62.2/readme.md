## Core type support for COM and Windows

The [windows-core](https://crates.io/crates/windows-core) crate provides core type support for the windows-* family of crates.

* [Getting started](https://kennykerr.ca/rust-getting-started/)
* [Samples](https://github.com/microsoft/windows-rs/tree/master/crates/samples)
* [Releases](https://github.com/microsoft/windows-rs/releases)
