pub mod serialize {
    pub trait Sealed {}
}

pub mod serializer {
    pub trait Sealed {}
}

pub mod deserializer {
    pub trait Sealed {}
}
