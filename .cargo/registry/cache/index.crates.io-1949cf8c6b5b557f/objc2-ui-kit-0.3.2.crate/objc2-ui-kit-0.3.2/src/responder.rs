use objc2_foundation::NSString;

extern "C" {
    pub static UIKeyInputF1: &'static NSString;
}
