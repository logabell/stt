package com.k2fsa.sherpa.onnx

data class SpeechContent(val text:String,val segment:Long)
