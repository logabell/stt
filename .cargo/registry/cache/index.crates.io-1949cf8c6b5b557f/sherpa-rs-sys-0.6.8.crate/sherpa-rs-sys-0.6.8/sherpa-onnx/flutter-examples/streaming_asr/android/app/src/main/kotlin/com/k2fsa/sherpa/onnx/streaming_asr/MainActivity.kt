package com.k2fsa.sherpa.onnx.streaming_asr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
