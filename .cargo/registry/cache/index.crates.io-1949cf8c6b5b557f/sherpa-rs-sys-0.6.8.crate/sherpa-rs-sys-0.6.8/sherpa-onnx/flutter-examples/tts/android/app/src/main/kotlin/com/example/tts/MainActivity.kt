package com.k2fsa.sherpa.onnx.tts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
