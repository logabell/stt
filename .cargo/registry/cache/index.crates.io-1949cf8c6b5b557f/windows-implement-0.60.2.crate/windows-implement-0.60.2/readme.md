## The implement macro for the Windows crates

See [windows-core](https://crates.io/crates/windows-core) for more information.
